# React Frontend + RAG Backend Integration Guide

This document explains how to run the integrated system with the React frontend connected to the RAG chatbot backend.

## System Architecture

```
┌─────────────────────────┐         ┌──────────────────────────┐
│   React Frontend        │         │   Flask Backend          │
│   (Port 5173)           │◄───────►│   (Port 5000)            │
│                         │  HTTP   │                          │
│  - Vite + TypeScript    │         │  - RAG Chatbot           │
│  - shadcn/ui            │         │  - GPT4All LLM           │
│  - TailwindCSS          │         │  - ChromaDB VectorStore  │
└─────────────────────────┘         └──────────────────────────┘
```

## Prerequisites

### Backend Requirements
- Python 3.8+
- 8GB RAM (16GB recommended)
- 10GB free disk space

### Frontend Requirements
- Node.js 16+ and npm
- Modern web browser

## Setup Instructions

### 1. Backend Setup

```bash
# Navigate to backend directory
cd CPAProject

# Install Python dependencies
pip install -r requirements.txt

# Ingest documents (first time only, takes 10-30 minutes)
python setup.py

# Start Flask backend
python app.py
```

Backend will run on: **http://localhost:5000**

### 2. Frontend Setup

```bash
# Navigate to frontend directory
cd wireframe-to-cpa-chat

# Install dependencies
npm install

# Start development server
npm run dev
```

Frontend will run on: **http://localhost:5173**

## Running the System

### Quick Start

**Terminal 1 (Backend):**
```bash
cd ~/Desktop/CPAProject
python app.py
```

**Terminal 2 (Frontend):**
```bash
cd ~/Desktop/wireframe-to-cpa-chat
npm run dev
```

**Then open:** http://localhost:5173/chat

## Configuration

### Backend Configuration

File: `CPAProject/.env`
```env
MODEL_NAME=nous-hermes-2-mistral-7b-dpo.Q4_0.gguf
CHROMA_DB_PATH=./chroma_db
COLLECTION_NAME=audit_documents
FLASK_PORT=5000
FLASK_DEBUG=True
```

### Frontend Configuration

File: `wireframe-to-cpa-chat/.env`
```env
VITE_API_URL=http://localhost:5000
```

## Features

### Integrated Features

1. **Real-time Chat**
   - Send messages to RAG backend
   - Receive Socratic responses
   - View referenced sources (audit standards, articles)

2. **Audit Scenarios**
   - Going Concern Assessment
   - Inventory Obsolescence
   - Revenue Recognition
   - Related Party Transactions

3. **Additional Functions**
   - 💡 Reflection Prompts (self-assessment)
   - 📊 System Statistics (documents, model info)
   - 🔄 Reset Conversation
   - Connection status indicator

4. **Source Attribution**
   - Shows which audit documents were referenced
   - Relevance scores for each source
   - Document type classification

## API Endpoints

### Available Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/chat` | POST | Send message to chatbot |
| `/api/scenario/{key}` | POST | Load audit scenario |
| `/api/reflect` | POST | Get reflection prompt |
| `/api/reset` | POST | Reset conversation |
| `/api/stats` | GET | Get system statistics |
| `/health` | GET | Health check |

### Example API Usage

**Send Message:**
```typescript
const response = await fetch('http://localhost:5000/api/chat', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ message: 'How do I assess going concern?' })
});

const data = await response.json();
// { response: "...", sources: [...], timestamp: "..." }
```

## Troubleshooting

### Backend Issues

**"Vector store is empty"**
```bash
cd CPAProject
python setup.py
```

**"Model not found"**
- GPT4All will auto-download (~4GB)
- Check `CPAProject/models/` directory

**Port 5000 in use**
```bash
# Change port in CPAProject/config.py
FLASK_PORT = 5001

# Update frontend .env
VITE_API_URL=http://localhost:5001
```

### Frontend Issues

**"Backend Not Connected"**
1. Ensure Flask backend is running
2. Check backend URL in `.env`
3. Verify CORS is enabled (should be automatic)

**Port 5173 in use**
```bash
# Vite will auto-assign next available port (5174, etc.)
# Update CPAProject/app.py CORS origins if needed
```

### CORS Issues

If you see CORS errors in browser console:

1. Check `CPAProject/app.py` has `flask-cors` imported
2. Verify origins list includes your frontend URL
3. Restart Flask backend

## Development Tips

### Hot Reload

Both frontend and backend support hot reload:
- **Frontend**: Vite auto-reloads on file changes
- **Backend**: Flask auto-reloads in debug mode

### Debugging

**Backend Logs:**
```bash
# Flask outputs to terminal
# Check for errors in backend terminal
```

**Frontend Logs:**
```javascript
// Open browser DevTools (F12)
// Check Console tab for errors
```

### Testing API Directly

```bash
# Health check
curl http://localhost:5000/health

# Send message
curl -X POST http://localhost:5000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"What is professional skepticism?"}'

# Get stats
curl http://localhost:5000/api/stats
```

## Project Structure

### Backend (CPAProject/)
```
CPAProject/
├── app.py                 # Flask server with CORS
├── rag_chatbot.py        # Main RAG logic
├── llm_engine.py         # GPT4All integration
├── vector_store.py       # ChromaDB wrapper
├── document_processor.py # PDF processing
├── config.py             # Configuration
├── setup.py              # Document ingestion
├── chroma_db/            # Vector database
└── models/               # GPT4All models
```

### Frontend (wireframe-to-cpa-chat/)
```
wireframe-to-cpa-chat/
├── src/
│   ├── pages/
│   │   └── Chat.tsx      # Main chat interface
│   ├── lib/
│   │   └── api.ts        # Backend API client
│   └── components/       # UI components
├── .env                  # Environment config
└── package.json          # Dependencies
```

## Performance Notes

### Response Times

- **First message**: 10-30 seconds (model loading)
- **Subsequent messages**: 5-15 seconds
- **Scenario loading**: 5-20 seconds

### Memory Usage

- **Backend**: 2-4GB (with model loaded)
- **Frontend**: ~100MB
- **Vector DB**: ~500MB-2GB (depends on documents)

## Production Deployment

For production deployment:

1. **Backend**:
   - Use production WSGI server (Gunicorn)
   - Set `FLASK_DEBUG=False`
   - Configure proper CORS origins
   - Add authentication/rate limiting

2. **Frontend**:
   - Build production bundle: `npm run build`
   - Serve with nginx or similar
   - Update `VITE_API_URL` to production backend

## Additional Resources

- **RAG Backend README**: `CPAProject/README.md`
- **Frontend README**: `wireframe-to-cpa-chat/README.md`
- **API Documentation**: See API endpoints section above

## Support

If you encounter issues:

1. Check both terminal windows for errors
2. Verify both servers are running
3. Check browser DevTools console
4. Review configuration files
5. Ensure documents are ingested (`setup.py`)

---

**System Status Checklist:**

- [ ] Backend running on port 5000
- [ ] Frontend running on port 5173
- [ ] Documents ingested (vector store populated)
- [ ] Model downloaded (~4GB)
- [ ] Browser shows "Connected" badge
- [ ] Can send messages and receive responses
