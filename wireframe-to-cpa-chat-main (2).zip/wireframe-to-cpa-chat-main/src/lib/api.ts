/**
 * API Service for RAG Chatbot Backend
 * Connects React frontend to Flask backend
 */

import { config } from '@/config';

export interface ChatMessage {
  id: string;
  content: string;
  sender: 'user' | 'assistant' | 'system';
  timestamp: Date;
  sources?: Source[];
  scenarioKey?: ScenarioKey;  // For scenario messages to enable download link
}

export interface Source {
  filename: string;
  type: string;
  score: number;
}

export interface ChatResponse {
  response: string;
  sources: Source[];
  timestamp: string;
}

export interface ScenarioResponse {
  scenario: string;
  scenario_key: string;
}

export interface ReflectionResponse {
  reflection: string;
  timestamp: string;
}

export interface IntroductionResponse {
  introduction: string;
  timestamp: string;
}

export interface SystemStats {
  vector_store: {
    name: string;
    count: number;
    persist_directory: string;
  };
  llm: {
    model_name: string;
    loaded: boolean;
    device: string;
  };
  conversation_length: number;
}

export interface HealthStatus {
  status: 'healthy' | 'not_initialized';
  timestamp: string;
}

export interface SessionSummaryResponse {
  summary: string;
  session_id: string;
  message_count: number;
  user_questions_count: number;
  timestamp: string;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface LoginResponse {
  token: string;
  username: string;
  expires_at: string;
}

export interface AnalyticsOverview {
  period_days: number;
  total_sessions: number;
  total_messages: number;
  avg_session_duration_seconds: number;
  avg_session_duration_minutes: number;
  avg_messages_per_session: number;
  top_scenarios: any[];
  reflection_usage: number;
  timestamp: string;
}

export interface DailyActivity {
  date: string;
  sessions: number;
  total_messages: number;
}

export interface ScenarioStats {
  scenario_key: string;
  total_loads: number;
  unique_sessions: number;
  avg_duration: number;
}

class APIService {
  // Get base URL from config
  private get baseUrl(): string {
    return config.apiUrl;
  }

  /**
   * Send a chat message to the RAG chatbot with optional scenario context
   */
  async sendMessage(message: string, scenarioKey?: string): Promise<ChatResponse> {
    const response = await fetch(`${this.baseUrl}/api/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        message,
        scenario_key: scenarioKey  // Pass active scenario for context-aware responses
      }),
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Unknown error' }));
      throw new Error(error.error || `HTTP ${response.status}`);
    }

    return response.json();
  }

  /**
   * Load a predefined audit scenario
   */
  async loadScenario(scenarioKey: string): Promise<ScenarioResponse> {
    const response = await fetch(`${this.baseUrl}/api/scenario/${scenarioKey}`, {
      method: 'POST',
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Unknown error' }));
      throw new Error(error.error || `HTTP ${response.status}`);
    }

    return response.json();
  }

  /**
   * Load the professional skepticism introduction
   */
  async loadIntroduction(): Promise<IntroductionResponse> {
    const response = await fetch(`${this.baseUrl}/api/introduction`, {
      method: 'POST',
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Unknown error' }));
      throw new Error(error.error || `HTTP ${response.status}`);
    }

    return response.json();
  }

  /**
   * Get a reflection prompt for self-assessment
   */
  async getReflection(): Promise<ReflectionResponse> {
    const response = await fetch(`${this.baseUrl}/api/reflect`, {
      method: 'POST',
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Unknown error' }));
      throw new Error(error.error || `HTTP ${response.status}`);
    }

    return response.json();
  }

  /**
   * Reset the conversation history
   */
  async resetConversation(): Promise<void> {
    const response = await fetch(`${this.baseUrl}/api/reset`, {
      method: 'POST',
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Unknown error' }));
      throw new Error(error.error || `HTTP ${response.status}`);
    }
  }

  /**
   * Get system statistics
   */
  async getStats(): Promise<SystemStats> {
    const response = await fetch(`${this.baseUrl}/api/stats`);

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Unknown error' }));
      throw new Error(error.error || `HTTP ${response.status}`);
    }

    return response.json();
  }

  /**
   * Check backend health status
   */
  async healthCheck(): Promise<HealthStatus> {
    const response = await fetch(`${this.baseUrl}/health`);

    if (!response.ok) {
      throw new Error(`Health check failed: HTTP ${response.status}`);
    }

    return response.json();
  }

  /**
   * Get a comprehensive session summary
   */
  async getSessionSummary(): Promise<SessionSummaryResponse> {
    const response = await fetch(`${this.baseUrl}/api/session/summary`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Unknown error' }));
      throw new Error(error.error || `HTTP ${response.status}`);
    }

    return response.json();
  }

  /**
   * Admin login
   */
  async login(username: string, password: string): Promise<LoginResponse> {
    const response = await fetch(`${this.baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password }),
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Invalid credentials' }));
      throw new Error(error.error || 'Login failed');
    }

    return response.json();
  }

  /**
   * Get analytics overview
   */
  async getAnalyticsOverview(days: number = 30): Promise<AnalyticsOverview> {
    const token = localStorage.getItem('admin_token');
    const response = await fetch(`${this.baseUrl}/api/analytics/overview?days=${days}`, {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Failed to fetch analytics' }));
      throw new Error(error.error || `HTTP ${response.status}`);
    }

    return response.json();
  }

  /**
   * Get daily activity
   */
  async getAnalyticsDaily(days: number = 7): Promise<DailyActivity[]> {
    const token = localStorage.getItem('admin_token');
    const response = await fetch(`${this.baseUrl}/api/analytics/daily?days=${days}`, {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Failed to fetch daily activity' }));
      throw new Error(error.error || `HTTP ${response.status}`);
    }

    return response.json();
  }

  /**
   * Get scenario statistics
   */
  async getAnalyticsScenarios(): Promise<ScenarioStats[]> {
    const token = localStorage.getItem('admin_token');
    const response = await fetch(`${this.baseUrl}/api/analytics/scenarios`, {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Failed to fetch scenario stats' }));
      throw new Error(error.error || `HTTP ${response.status}`);
    }

    return response.json();
  }

  /**
   * Get recent sessions
   */
  async getAnalyticsSessions(limit: number = 20): Promise<any[]> {
    const token = localStorage.getItem('admin_token');
    const response = await fetch(`${this.baseUrl}/api/analytics/sessions?limit=${limit}`, {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Failed to fetch sessions' }));
      throw new Error(error.error || `HTTP ${response.status}`);
    }

    return response.json();
  }
}

// Export singleton instance
export const apiService = new APIService();

// Export audit scenarios - Updated with 5 comprehensive cases
export const AUDIT_SCENARIOS = {
  blue_forge_steel: {
    key: 'blue_forge_steel',
    title: 'Case 1: Blue Forge Steel - Going Concern',
    description: 'Manufacturing client with financial distress and going concern issues'
  },
  zephora_retail: {
    key: 'zephora_retail',
    title: 'Case 2: Zephora Retail - Fraud & Override',
    description: 'Retail chain with fraud indicators and management override of controls'
  },
  solutions_tech: {
    key: 'solutions_tech',
    title: 'Case 3: Solutions Tech - Revenue Recognition',
    description: 'Software company with AASB 15 revenue recognition challenges'
  },
  orion_tech: {
    key: 'orion_tech',
    title: 'Case 4: Orion Tech - Related Party',
    description: 'Technology firm with undisclosed related party transactions'
  },
  aussie_pizza: {
    key: 'aussie_pizza',
    title: 'Case 5: Aussie Pizza - Fair Value & Impairment',
    description: 'Restaurant chain with impairment testing and fair value issues'
  }
} as const;

export type ScenarioKey = keyof typeof AUDIT_SCENARIOS;
