import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Calendar, Clock, User, Phone, Mail } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import Footer from "@/components/Footer";

const Booking = () => {
  const navigate = useNavigate();
  const [selectedDate, setSelectedDate] = useState<string>("");
  const [selectedTime, setSelectedTime] = useState<string>("");
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: ""
  });

  const timeSlots = [
    "09:00", "09:30", "10:00", "10:30", "11:00", "11:30",
    "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00"
  ];

  const generateCalendar = () => {
    const today = new Date();
    const calendar = [];
    
    for (let i = 0; i < 14; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      
      // Skip weekends
      if (date.getDay() !== 0 && date.getDay() !== 6) {
        calendar.push({
          date: date.toISOString().split('T')[0],
          day: date.getDate(),
          dayName: date.toLocaleDateString('en', { weekday: 'short' }),
          isToday: i === 0
        });
      }
    }
    
    return calendar.slice(0, 10); // Show 10 business days
  };

  const handleBooking = () => {
    if (!selectedDate || !selectedTime || !formData.name || !formData.email) {
      alert("Please fill in all required fields and select a date and time.");
      return;
    }
    
    // Here you would typically send the booking data to your backend
    alert("Consultation booked successfully! You will receive a confirmation email shortly.");
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gradient-subtle">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={() => navigate('/chat')}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Chat
            </Button>
            <div className="flex items-center space-x-2">
              <Calendar className="w-6 h-6 text-primary" />
              <span className="text-xl font-semibold text-primary">Book a Consultation</span>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto max-w-4xl px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Date & Time Selection */}
          <Card className="p-6">
            <h2 className="text-xl font-semibold text-primary mb-6 flex items-center">
              <Calendar className="w-5 h-5 mr-2" />
              Select Date and Time
            </h2>
            
            {/* Date Selection */}
            <div className="mb-6">
              <Label className="text-sm font-medium text-foreground mb-3 block">Choose Date</Label>
              <div className="grid grid-cols-5 gap-2">
                {generateCalendar().map((day) => (
                  <Button
                    key={day.date}
                    variant={selectedDate === day.date ? "default" : "outline"}
                    size="sm"
                    className={`flex flex-col py-3 h-auto ${
                      selectedDate === day.date ? 'bg-primary text-primary-foreground' : ''
                    }`}
                    onClick={() => setSelectedDate(day.date)}
                  >
                    <span className="text-xs opacity-70">{day.dayName}</span>
                    <span className="text-lg font-semibold">{day.day}</span>
                  </Button>
                ))}
              </div>
            </div>

            {/* Time Selection */}
            {selectedDate && (
              <div>
                <Label className="text-sm font-medium text-foreground mb-3 block flex items-center">
                  <Clock className="w-4 h-4 mr-1" />
                  Choose Time
                </Label>
                <div className="grid grid-cols-4 gap-2">
                  {timeSlots.map((time) => (
                    <Button
                      key={time}
                      variant={selectedTime === time ? "default" : "outline"}
                      size="sm"
                      className={selectedTime === time ? 'bg-primary text-primary-foreground' : ''}
                      onClick={() => setSelectedTime(time)}
                    >
                      {time}
                    </Button>
                  ))}
                </div>
              </div>
            )}
          </Card>

          {/* Contact Information */}
          <Card className="p-6">
            <h2 className="text-xl font-semibold text-primary mb-6 flex items-center">
              <User className="w-5 h-5 mr-2" />
              Your Information
            </h2>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="name" className="text-sm font-medium">Full Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="mt-1"
                  placeholder="Enter your full name"
                />
              </div>

              <div>
                <Label htmlFor="email" className="text-sm font-medium flex items-center">
                  <Mail className="w-4 h-4 mr-1" />
                  Email Address *
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                  className="mt-1"
                  placeholder="Enter your email address"
                />
              </div>

              <div>
                <Label htmlFor="phone" className="text-sm font-medium flex items-center">
                  <Phone className="w-4 h-4 mr-1" />
                  Phone Number
                </Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                  className="mt-1"
                  placeholder="Enter your phone number"
                />
              </div>

              <div>
                <Label htmlFor="message" className="text-sm font-medium">
                  What would you like to discuss?
                </Label>
                <Textarea
                  id="message"
                  value={formData.message}
                  onChange={(e) => setFormData(prev => ({ ...prev, message: e.target.value }))}
                  className="mt-1 h-24"
                  placeholder="Briefly describe your accounting or tax questions..."
                />
              </div>
            </div>

            {/* Booking Summary */}
            {selectedDate && selectedTime && (
              <Card className="mt-6 p-4 bg-accent/10 border-accent/20">
                <h3 className="font-medium text-accent mb-2">Booking Summary</h3>
                <div className="text-sm text-muted-foreground space-y-1">
                  <p>Date: {new Date(selectedDate).toLocaleDateString('en', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                  <p>Time: {selectedTime}</p>
                  <p>Duration: 30 minutes</p>
                  <p>Type: Virtual Consultation</p>
                </div>
              </Card>
            )}

            <Button 
              className="w-full mt-6 bg-gradient-primary hover:opacity-90 text-lg py-6"
              onClick={handleBooking}
              disabled={!selectedDate || !selectedTime || !formData.name || !formData.email}
            >
              Book Consultation
            </Button>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Booking;