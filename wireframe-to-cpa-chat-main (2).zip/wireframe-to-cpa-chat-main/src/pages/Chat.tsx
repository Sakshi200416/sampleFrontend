import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Send, MessageCircle, RotateCcw, Download, ChevronDown, ChevronUp, FileText, GraduationCap, PanelLeftClose, PanelLeft, X } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { apiService, AUDIT_SCENARIOS, type ScenarioKey } from "@/lib/api";
import { toast } from "sonner";
import { config } from "@/config";
import ReactMarkdown from "react-markdown";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

type Message = {
  id: string;
  content: string;
  sender: 'user' | 'assistant';
  timestamp: Date;
  scenarioKey?: string;
  sources?: Array<{filename: string; type: string; score: number}>;
};

const Chat = () => {
  const navigate = useNavigate();
  const initialMessage: Message = {
    id: '1',
    content: "Welcome to Professional Scepticism Training! I'm here to help you develop critical audit judgement through Socratic dialogue. Click 'Start Learning' below to begin with an overview of professional scepticism, or select a scenario to dive into a case.",
    sender: 'assistant',
    timestamp: new Date()
  };

  const [messages, setMessages] = useState<Message[]>([initialMessage]);
  const [inputMessage, setInputMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [scenariosExpanded, setScenariosExpanded] = useState(true);
  const [hasSelectedScenario, setHasSelectedScenario] = useState(false);
  const [selectedScenarioName, setSelectedScenarioName] = useState("");
  const [currentScenarioKey, setCurrentScenarioKey] = useState<ScenarioKey | null>(null);
  const [scenarioText, setScenarioText] = useState<string>("");
  const [scenarioPanelOpen, setScenarioPanelOpen] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scenarios = Object.entries(AUDIT_SCENARIOS).map(([key, scenario]) => ({
    key: key as ScenarioKey,
    label: scenario.title,
    action: () => handleLoadScenario(key as ScenarioKey)
  }));

  // Auto-scroll to latest message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);


  const handleLoadScenario = async (scenarioKey: ScenarioKey) => {
    setIsLoading(true);
    setHasSelectedScenario(true);
    setScenariosExpanded(false);
    setCurrentScenarioKey(scenarioKey);
    setSelectedScenarioName(AUDIT_SCENARIOS[scenarioKey].title);
    setScenarioPanelOpen(true);

    try {
      const response = await apiService.loadScenario(scenarioKey);

      // Store scenario text for the panel
      setScenarioText(response.scenario);

      // Add only a brief notification to chat (NOT the full scenario text)
      const scenarioLoadedMessage: Message = {
        id: Date.now().toString(),
        content: `📋 **${AUDIT_SCENARIOS[scenarioKey].title}** loaded. Review the case details in the panel on the left, then ask questions to begin your analysis.`,
        sender: 'assistant',
        timestamp: new Date(),
        scenarioKey: scenarioKey
      };
      setMessages(prev => [...prev, scenarioLoadedMessage]);
      toast.success("Scenario loaded! Review the case details.");
    } catch (error) {
      toast.error(`Error: ${error}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || isLoading) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      content: inputMessage,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, newMessage]);
    setInputMessage("");
    setIsLoading(true);

    try {
      // Pass current scenario key for context-aware responses
      const response = await apiService.sendMessage(
        inputMessage,
        currentScenarioKey || undefined
      );
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: response.response,
        sender: 'assistant',
        timestamp: new Date(response.timestamp),
        sources: response.sources
      };
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      toast.error(`Error: ${error}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownloadScenario = (scenarioKey: string) => {
    const downloadUrl = `${config.apiUrl}/api/download/${scenarioKey}`;
    window.open(downloadUrl, '_blank');
    toast.success("Downloading scenario document...");
  };

  const handleDownloadSource = (filename: string) => {
    const downloadUrl = `${config.apiUrl}/api/download-source?filename=${encodeURIComponent(filename)}`;
    window.open(downloadUrl, '_blank');
    toast.success("Downloading source document...");
  };

  const handleRefreshChat = () => {
    setMessages([{
      ...initialMessage,
      id: Date.now().toString(),
      timestamp: new Date()
    }]);
    setInputMessage("");
  };

  return (
    <div className="h-screen bg-background flex flex-col">
      {/* Header - Fixed */}
      <header className="flex-none border-b bg-card shadow-soft">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" onClick={() => navigate('/')}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-primary rounded-lg flex items-center justify-center">
                  <MessageCircle className="w-5 h-5 text-primary-foreground" />
                </div>
                <span className="text-lg font-semibold text-primary">CPA Chatbot</span>
              </div>
              {/* Status Badge */}
              {currentScenarioKey ? (
                <Badge variant="default" className="bg-emerald-600">
                  📍 {selectedScenarioName}
                </Badge>
              ) : (
                <Badge variant="outline">💬 General Mode</Badge>
              )}
            </div>
            <div className="flex items-center space-x-2">
              {currentScenarioKey && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setScenarioPanelOpen(!scenarioPanelOpen)}
                  title={scenarioPanelOpen ? "Hide case details" : "Show case details"}
                >
                  {scenarioPanelOpen ? <PanelLeftClose className="w-4 h-4" /> : <PanelLeft className="w-4 h-4" />}
                </Button>
              )}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/reference')}
                title="Professional Scepticism Guide & FAQ"
              >
                <GraduationCap className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={handleRefreshChat} title="Restart Chat">
                <RotateCcw className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Area with Scenario Panel */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left: Scenario Panel (Collapsible) */}
        {currentScenarioKey && scenarioPanelOpen && (
          <div className="w-96 border-r bg-muted/30 overflow-y-auto p-4 flex-shrink-0">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-primary">📋 Case Details</h2>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setScenarioPanelOpen(false)}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
            <div className="prose prose-sm max-w-none leading-relaxed [&>p]:mb-3 [&>ul]:mb-3 [&>ol]:mb-3 [&>ul]:ml-4 [&>ol]:ml-4 [&>li]:mb-1 [&>h1]:text-xl [&>h1]:font-bold [&>h1]:mb-2 [&>h2]:text-lg [&>h2]:font-bold [&>h2]:mb-2 [&>h3]:text-base [&>h3]:font-bold [&>h3]:mb-2">
              <ReactMarkdown>{scenarioText}</ReactMarkdown>
            </div>
            {currentScenarioKey && (
              <div className="mt-4 pt-4 border-t">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleDownloadScenario(currentScenarioKey)}
                  className="w-full"
                >
                  <Download className="w-3 h-3 mr-2" />
                  Download Case Document
                </Button>
              </div>
            )}
          </div>
        )}

        {/* Right: Chat Messages - Scrollable */}
        <div className="flex-1 overflow-y-auto p-4">
          <div className="container mx-auto max-w-4xl">
          {messages.map((message) => (
            <div key={message.id} className="mb-6">
              {/* All messages left-aligned */}
              <div className="w-full">
                <div className={`rounded-2xl px-5 py-4 ${
                  message.sender === 'user'
                    ? 'bg-primary/10 border border-primary/20'
                    : 'bg-muted/30'
                }`}>
                  {message.sender === 'user' && (
                    <p className="text-xs font-semibold text-primary mb-2">You</p>
                  )}
                  <div className="leading-relaxed [&>p]:mb-3 [&>p:last-child]:mb-0 [&>ul]:mb-3 [&>ol]:mb-3 [&>ul]:ml-4 [&>ol]:ml-4 [&>li]:mb-1 [&>h1]:text-xl [&>h1]:font-bold [&>h1]:mb-2 [&>h2]:text-lg [&>h2]:font-bold [&>h2]:mb-2 [&>h3]:text-base [&>h3]:font-bold [&>h3]:mb-2">
                    <ReactMarkdown>{message.content}</ReactMarkdown>
                  </div>

                  {/* Download Scenario Button */}
                  {message.scenarioKey && (
                    <div className="mt-4 pt-4 border-t border-border">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDownloadScenario(message.scenarioKey!)}
                        className="bg-background"
                      >
                        <Download className="w-3 h-3 mr-2" />
                        Download Scenario Document
                      </Button>
                    </div>
                  )}

                  {/* Sources - Collapsible */}
                  {message.sources && message.sources.length > 0 && (
                    <Collapsible className="mt-4 pt-4 border-t border-border">
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full justify-between hover:bg-muted/50">
                          <span className="flex items-center text-xs font-semibold text-muted-foreground">
                            <FileText className="w-3 h-3 mr-2" />
                            Referenced Sources ({message.sources.length})
                          </span>
                          <ChevronDown className="w-4 h-4" />
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-2">
                        <div className="space-y-1">
                          {message.sources.map((source, idx) => (
                            <div key={idx} className="flex items-center justify-between text-xs bg-background rounded px-2 py-1.5">
                              <span className="text-sm">{source.filename}</span>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-7 px-2 hover:bg-muted"
                                onClick={() => handleDownloadSource(source.filename)}
                              >
                                <Download className="w-3 h-3" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      </CollapsibleContent>
                    </Collapsible>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
        </div>
      </div>

      {/* Audit Scenarios - Collapsible after selection */}
      <div className="flex-none border-t bg-gradient-to-r from-teal-50 to-emerald-50">
        <div className="container mx-auto max-w-4xl">
          <Collapsible open={scenariosExpanded} onOpenChange={setScenariosExpanded}>
            <CollapsibleTrigger asChild>
              <Button
                variant="ghost"
                className="w-full py-4 hover:bg-teal-100/50 flex items-center justify-between"
              >
                <span className="text-sm font-semibold text-primary">
                  {hasSelectedScenario ? `Audit Scenarios - ${selectedScenarioName}` : 'Select an Audit Scenario'}
                </span>
                {hasSelectedScenario && (
                  scenariosExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />
                )}
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent>
              {/* Start Learning Button */}
              <div className="px-4 pt-4 pb-2">
                <Button
                  variant="default"
                  size="lg"
                  onClick={() => navigate('/reference')}
                  className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-semibold py-4 shadow-md"
                >
                  <GraduationCap className="w-5 h-5 mr-2" />
                  Start Learning: Professional Scepticism Overview
                </Button>
              </div>

              {/* Scenario Buttons */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 px-4 pb-4 pt-2">
                {scenarios.map((scenario) => (
                  <Button
                    key={scenario.key}
                    variant="outline"
                    size="default"
                    onClick={scenario.action}
                    disabled={isLoading}
                    className="text-sm bg-white hover:bg-teal-100 border-teal-300 text-teal-900 font-medium py-3 px-4 h-auto whitespace-normal text-left justify-start"
                  >
                    {scenario.label}
                  </Button>
                ))}
              </div>
            </CollapsibleContent>
          </Collapsible>
        </div>
      </div>

      {/* Message Input - Fixed */}
      <div className="flex-none border-t bg-card p-4">
        <div className="container mx-auto max-w-4xl">
          <div className="flex space-x-4">
            <Input
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Type your message..."
              className="flex-1 h-12"
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            />
            <Button
              onClick={handleSendMessage}
              className="h-12 px-6 bg-gradient-primary hover:opacity-90"
              disabled={!inputMessage.trim() || isLoading}
            >
              {isLoading ? "..." : <Send className="w-4 h-4" />}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Chat;