import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Upload, FileText, X, CheckCircle2, AlertCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Footer from "@/components/Footer";

type UploadedFile = {
  id: string;
  name: string;
  size: number;
  type: string;
  status: 'uploading' | 'uploaded' | 'error';
};

const UploadPage = () => {
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragActive, setDragActive] = useState(false);
  const [files, setFiles] = useState<UploadedFile[]>([]);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(Array.from(e.dataTransfer.files));
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      handleFiles(Array.from(e.target.files));
    }
  };

  const handleFiles = (fileList: File[]) => {
    const newFiles = fileList.map(file => ({
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      name: file.name,
      size: file.size,
      type: file.type,
      status: 'uploading' as const
    }));

    setFiles(prev => [...prev, ...newFiles]);

    // Simulate upload process
    newFiles.forEach(file => {
      setTimeout(() => {
        setFiles(prev => prev.map(f => 
          f.id === file.id ? { ...f, status: 'uploaded' } : f
        ));
      }, 1000 + Math.random() * 2000);
    });
  };

  const removeFile = (fileId: string) => {
    setFiles(prev => prev.filter(f => f.id !== fileId));
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = (type: string) => {
    if (type.includes('pdf')) return '📄';
    if (type.includes('image')) return '🖼️';
    if (type.includes('spreadsheet') || type.includes('excel')) return '📊';
    if (type.includes('document') || type.includes('word')) return '📋';
    return '📁';
  };

  const handleReviewAndSubmit = () => {
    const uploadedFiles = files.filter(f => f.status === 'uploaded');
    if (uploadedFiles.length === 0) {
      alert("Please upload at least one file before submitting.");
      return;
    }
    
    // Here you would typically process the files
    alert(`${uploadedFiles.length} file(s) submitted successfully! Our CPA will review them and get back to you.`);
    navigate('/chat');
  };

  return (
    <div className="min-h-screen bg-gradient-subtle">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={() => navigate('/chat')}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Chat
            </Button>
            <div className="flex items-center space-x-2">
              <Upload className="w-6 h-6 text-primary" />
              <span className="text-xl font-semibold text-primary">Upload Documents</span>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto max-w-4xl px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Upload Area */}
          <div>
            <Card className="p-6">
              <h2 className="text-xl font-semibold text-primary mb-4">Upload Your Documents</h2>
              <p className="text-muted-foreground mb-6">
                Upload your financial documents for professional review. We accept PDF, Excel, Word, and image files.
              </p>

              {/* Drag and Drop Area */}
              <div
                className={`
                  relative border-2 border-dashed rounded-lg p-8 text-center transition-colors
                  ${dragActive 
                    ? 'border-accent bg-accent/10' 
                    : 'border-border hover:border-accent/50 bg-muted/30'
                  }
                `}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  onChange={handleFileInput}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  accept=".pdf,.doc,.docx,.xls,.xlsx,.png,.jpg,.jpeg"
                />
                
                <div className="pointer-events-none">
                  <Upload className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-foreground mb-2">
                    Drag and drop files here
                  </h3>
                  <p className="text-muted-foreground mb-4">
                    or click to browse your files
                  </p>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    Choose Files
                  </Button>
                </div>
              </div>

              <div className="mt-4 text-xs text-muted-foreground">
                <p>Supported formats: PDF, DOC, DOCX, XLS, XLSX, PNG, JPG, JPEG</p>
                <p>Maximum file size: 10MB per file</p>
              </div>
            </Card>

            {/* Security Notice */}
            <Card className="p-4 mt-4 bg-accent/10 border-accent/20">
              <div className="flex items-start space-x-3">
                <CheckCircle2 className="w-5 h-5 text-accent mt-0.5" />
                <div>
                  <h3 className="font-medium text-accent">Secure Upload</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Your documents are encrypted and securely stored. Only authorized CPAs will have access for review.
                  </p>
                </div>
              </div>
            </Card>
          </div>

          {/* Uploaded Files */}
          <div>
            <Card className="p-6">
              <h2 className="text-xl font-semibold text-primary mb-4">Uploaded Files</h2>
              
              {files.length === 0 ? (
                <div className="text-center py-8">
                  <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">No files uploaded yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {files.map((file) => (
                    <div
                      key={file.id}
                      className="flex items-center justify-between p-3 border rounded-lg bg-card"
                    >
                      <div className="flex items-center space-x-3 flex-1 min-w-0">
                        <span className="text-xl">{getFileIcon(file.type)}</span>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-foreground truncate">
                            {file.name}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {formatFileSize(file.size)}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-2 ml-2">
                        {file.status === 'uploading' && (
                          <div className="w-4 h-4 border-2 border-accent border-t-transparent rounded-full animate-spin" />
                        )}
                        {file.status === 'uploaded' && (
                          <CheckCircle2 className="w-4 h-4 text-success" />
                        )}
                        {file.status === 'error' && (
                          <AlertCircle className="w-4 h-4 text-destructive" />
                        )}
                        
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeFile(file.id)}
                          className="h-8 w-8 p-0"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {files.length > 0 && (
                <div className="mt-6 pt-4 border-t">
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-sm text-muted-foreground">
                      {files.filter(f => f.status === 'uploaded').length} of {files.length} files ready
                    </span>
                  </div>
                  
                  <Button 
                    className="w-full bg-gradient-primary hover:opacity-90"
                    onClick={handleReviewAndSubmit}
                    disabled={files.filter(f => f.status === 'uploaded').length === 0}
                  >
                    Review & Submit Documents
                  </Button>
                </div>
              )}
            </Card>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default UploadPage;