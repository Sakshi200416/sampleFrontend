import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { MessageCircle, GraduationCap, CheckCircle, BarChart, Lightbulb, Award, Clock } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Footer from "@/components/Footer";
import cpaLogo from "@/assets/cpa-logo.webp";
import jcuLogo from "@/assets/jcu-logo-clear.jpg";

const Landing = () => {
  const navigate = useNavigate();

  const authorityBlocks = [
    {
      icon: GraduationCap,
      title: "Academic Rigor",
      subtitle: "James Cook University",
      description: "Built on years of peer-reviewed accounting pedagogy, ensuring effective learning."
    },
    {
      icon: CheckCircle,
      title: "Socratic Method",
      subtitle: "Focused on Critical Thinking",
      description: "The AI probes your reasoning and challenges your assumptions to force deeper understanding."
    },
    {
      icon: BarChart,
      title: "Industry Alignment",
      subtitle: "Based on Official Standards",
      description: "Fully aligned with US GAAP, IFRS, and PCAOB audit standards and principles."
    }
  ];

  const features = [
    {
      icon: Lightbulb,
      title: "Clarity: Navigate Ambiguity",
      description: "Practice complex accounting treatments and vague client scenarios until you confidently own your conclusion."
    },
    {
      icon: Award,
      title: "Confidence: Judgment Practice",
      description: "Hundreds of real-world scenarios to build the professional skepticism and judgment expected from senior auditors."
    },
    {
      icon: Clock,
      title: "Convenience: 24/7 Academic Coach",
      description: "Accessible anytime, anywhere, allowing staff to prepare for certifications or engagements at their own pace."
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-subtle">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-gradient-primary rounded-lg flex items-center justify-center shadow-sm">
                <GraduationCap className="w-6 h-6 text-primary-foreground" />
              </div>
            </div>
            <Button variant="outline" size="sm" onClick={() => navigate('/login')}>
              Sign In
            </Button>
          </div>
        </div>
      </header>

      {/* Main Section - Two Column Layout */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-7xl">
          <div className="grid lg:grid-cols-2 gap-6 items-start">

            {/* Left Column - Hero Content */}
            <div className="flex flex-col justify-center">
              <h1 className="text-5xl md:text-6xl font-bold text-primary mb-6 leading-tight">
                The University-Vetted Socratic AI:
                <span className="block text-accent">Mastering Audit Judgement</span>
              </h1>
              <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
                Transform book knowledge into critical professional judgement. Stop memorising. Start reasoning.
              </p>
              <div className="space-y-6">
                <Button
                  size="lg"
                  className="bg-gradient-primary hover:opacity-90 transition-opacity text-lg px-8 py-6 shadow-medium w-fit"
                  onClick={() => navigate('/chat')}
                >
                  <GraduationCap className="w-5 h-5 mr-2" />
                  Begin Your First Case Simulation
                </Button>

                {/* Partner Logos */}
                <div className="flex flex-col space-y-4">
                  <p className="text-sm font-medium text-muted-foreground">Proudly supported by</p>
                  <div className="flex items-center gap-6">
                    <img
                      src={cpaLogo}
                      alt="CPA Australia - Australian Society of CPAs"
                      className="h-20 w-auto object-contain"
                    />
                    <img
                      src={jcuLogo}
                      alt="James Cook University Australia"
                      className="h-20 w-auto object-contain"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column - Authority & Benefits */}
            <div className="space-y-6">

              {/* Why Trust Us */}
              <div>
                <h2 className="text-2xl font-bold text-primary mb-6">
                  Why Trust Us?
                </h2>
                <div className="grid grid-cols-3 gap-6">
                  {authorityBlocks.map((block, index) => (
                    <Card key={index} className="p-4 hover:shadow-lg transition-shadow bg-gradient-to-br from-primary/5 to-accent/5 flex flex-col h-full">
                      <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-3">
                        <block.icon className="w-6 h-6 text-accent" />
                      </div>
                      <h3 className="text-sm font-bold text-primary mb-1">{block.title}</h3>
                      <p className={`text-xs mb-2 ${index === 0 ? 'font-bold text-primary' : 'font-semibold text-accent'}`}>{block.subtitle}</p>
                      <p className="text-xs text-muted-foreground leading-relaxed">{block.description}</p>
                    </Card>
                  ))}
                </div>
              </div>

              {/* The Auditor's Benefit */}
              <div>
                <h2 className="text-2xl font-bold text-primary mb-6">
                  The Auditor's Benefit
                </h2>
                <div className="grid grid-cols-3 gap-6">
                  {features.map((feature, index) => (
                    <Card key={index} className="p-4 hover:shadow-medium transition-shadow flex flex-col h-full">
                      <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center mb-3">
                        <feature.icon className="w-5 h-5 text-accent" />
                      </div>
                      <h3 className="text-sm font-bold text-card-foreground mb-2">{feature.title}</h3>
                      <p className="text-xs text-muted-foreground leading-relaxed">{feature.description}</p>
                    </Card>
                  ))}
                </div>
              </div>

            </div>

          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Landing;