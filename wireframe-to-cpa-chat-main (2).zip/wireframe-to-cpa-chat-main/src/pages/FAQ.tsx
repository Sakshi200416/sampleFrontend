import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, HelpCircle, MessageCircle, Search } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import Footer from "@/components/Footer";

const FAQ = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");

  const faqData = [
    {
      category: "Tax Filing & Compliance",
      questions: [
        {
          question: "When is the deadline for filing my annual tax return?",
          answer: "For individual tax returns, the deadline is typically April 30th (or the next business day if it falls on a weekend). For businesses, corporate tax returns are due 6 months after the fiscal year-end. However, you can request an extension if needed. We recommend filing early to avoid last-minute stress and potential penalties."
        },
        {
          question: "What documents do I need to prepare my taxes?",
          answer: "You'll need: T4 slips from employers, T5 slips for investment income, receipts for deductible expenses, charitable donation receipts, medical expense receipts, RRSP contribution slips, and any business income records. Keep all documents organized throughout the year to make tax preparation smoother."
        },
        {
          question: "Can I claim home office expenses if I work from home?",
          answer: "Yes, if you use part of your home exclusively for work, you can claim home office expenses. This includes a portion of utilities, insurance, property taxes, and maintenance costs. The space must be used primarily (more than 50%) for earning income. Keep detailed records and measurements of your workspace."
        },
        {
          question: "What's the difference between a tax deduction and a tax credit?",
          answer: "A tax deduction reduces your taxable income (saving you tax at your marginal rate), while a tax credit directly reduces the tax you owe dollar-for-dollar. For example, a $1,000 deduction might save you $300 in taxes if you're in a 30% tax bracket, but a $1,000 credit saves you the full $1,000."
        }
      ]
    },
    {
      category: "Business Accounting",
      questions: [
        {
          question: "How often should I update my bookkeeping?",
          answer: "Ideally, update your books weekly or at minimum monthly. Regular bookkeeping helps you track cash flow, make informed business decisions, and ensures you're prepared for tax time. Many businesses find weekly updates manageable and provide timely financial insights."
        },
        {
          question: "What's the difference between cash and accrual accounting?",
          answer: "Cash accounting records transactions when money changes hands, while accrual accounting records them when they're earned or incurred, regardless of payment timing. Most small businesses use cash accounting for simplicity, but larger businesses (over $5M revenue) must use accrual accounting."
        },
        {
          question: "Do I need to register for GST/HST?",
          answer: "You must register for GST/HST if your business revenue exceeds $30,000 in any 12-month period. You can voluntarily register earlier if beneficial. Registration allows you to claim input tax credits on business purchases but requires you to collect and remit GST/HST on sales."
        },
        {
          question: "How do I prepare a Business Activity Statement (BAS)?",
          answer: "Your BAS reports GST collected on sales minus GST paid on purchases. Gather all invoices, receipts, and sales records for the quarter. Calculate total sales (including GST), total purchases (including GST), then determine if you owe money or are due a refund. File by the 28th of the month following the quarter end."
        }
      ]
    },
    {
      category: "Business Setup & Structure",
      questions: [
        {
          question: "Should I incorporate my business or remain a sole proprietor?",
          answer: "Incorporation offers liability protection and potential tax advantages but involves more complexity and costs. Sole proprietorship is simpler but offers no liability protection. Consider factors like income level, liability exposure, growth plans, and administrative capacity. We can help analyze your specific situation."
        },
        {
          question: "What business expenses can I deduct?",
          answer: "Generally, expenses that are reasonable and necessary for earning business income are deductible. This includes office supplies, professional fees, travel expenses, advertising, equipment, insurance, and phone bills. Personal expenses cannot be deducted. Keep detailed records and receipts for all business expenses."
        },
        {
          question: "How do I separate business and personal finances?",
          answer: "Open separate business bank accounts and credit cards. Use business accounts only for business transactions. Pay yourself a salary or draws rather than mixing funds. This separation simplifies bookkeeping, protects liability protection (if incorporated), and makes tax preparation much easier."
        },
        {
          question: "What records should I keep and for how long?",
          answer: "Keep all business records for at least 6 years from the end of the tax year they relate to. This includes invoices, receipts, bank statements, contracts, and tax returns. Store them securely (physical or digital) and organize by year and category for easy retrieval."
        }
      ]
    },
    {
      category: "Personal Finance & Planning",
      questions: [
        {
          question: "How much should I contribute to my RRSP?",
          answer: "You can contribute up to 18% of your previous year's earned income, to a maximum limit ($31,560 for 2024). Unused contribution room carries forward indefinitely. Consider your current tax bracket, retirement goals, and other savings priorities. Higher earners often benefit more from RRSP contributions."
        },
        {
          question: "What's the difference between RRSP and TFSA?",
          answer: "RRSP contributions are tax-deductible now but withdrawals are taxable in retirement. TFSA contributions aren't deductible but growth and withdrawals are tax-free. RRSPs are better for retirement savings when you expect lower income later. TFSAs are more flexible for any savings goal."
        },
        {
          question: "Should I pay down debt or invest?",
          answer: "Generally, pay off high-interest debt (credit cards, personal loans) first. For lower-interest debt like mortgages, it depends on expected investment returns versus interest rates. Consider your risk tolerance, emergency fund status, and tax implications. A balanced approach often works best."
        },
        {
          question: "How can I minimize my tax burden legally?",
          answer: "Maximize RRSP contributions, use TFSA effectively, claim all eligible deductions and credits, consider income splitting strategies with family members, time capital gains/losses strategically, and ensure proper business expense documentation. Tax planning should be year-round, not just at tax time."
        }
      ]
    }
  ];

  const filteredFAQ = faqData.map(category => ({
    ...category,
    questions: category.questions.filter(
      q => 
        q.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
        q.answer.toLowerCase().includes(searchTerm.toLowerCase())
    )
  })).filter(category => category.questions.length > 0);

  return (
    <div className="min-h-screen bg-gradient-subtle">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={() => navigate('/chat')}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Chat
            </Button>
            <div className="flex items-center space-x-2">
              <HelpCircle className="w-6 h-6 text-primary" />
              <span className="text-xl font-semibold text-primary">Frequently Asked Questions</span>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto max-w-4xl px-4 py-8">
        {/* Introduction */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-primary mb-4">
            Common Questions About Accounting & Tax
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Find answers to the most frequently asked questions about accounting, tax filing, 
            business setup, and financial planning. Can't find what you're looking for? 
            Start a chat with our CPA assistant.
          </p>
        </div>

        {/* Search */}
        <Card className="p-4 mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search FAQ..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </Card>

        {/* FAQ Content */}
        <div className="space-y-8">
          {filteredFAQ.length === 0 ? (
            <Card className="p-8 text-center">
              <HelpCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">No results found</h3>
              <p className="text-muted-foreground">
                Try adjusting your search terms or browse through our categories below.
              </p>
            </Card>
          ) : (
            filteredFAQ.map((category, categoryIndex) => (
              <Card key={categoryIndex} className="p-6">
                <h2 className="text-xl font-semibold text-primary mb-4 flex items-center">
                  <div className="w-2 h-2 bg-accent rounded-full mr-3"></div>
                  {category.category}
                </h2>
                
                <Accordion type="single" collapsible className="space-y-2">
                  {category.questions.map((faq, index) => (
                    <AccordionItem key={index} value={`${categoryIndex}-${index}`} className="border rounded-lg px-4">
                      <AccordionTrigger className="text-left font-medium hover:no-underline py-4">
                        {faq.question}
                      </AccordionTrigger>
                      <AccordionContent className="text-muted-foreground leading-relaxed pb-4">
                        {faq.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </Card>
            ))
          )}
        </div>

        {/* Call to Action */}
        <Card className="mt-12 p-8 text-center bg-gradient-primary text-primary-foreground">
          <h2 className="text-2xl font-bold mb-4">Still Have Questions?</h2>
          <p className="text-lg mb-6 opacity-90">
            Our CPA assistant is available 24/7 to provide personalized answers to your specific accounting and tax questions.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              variant="secondary"
              className="text-lg px-8 py-6"
              onClick={() => navigate('/chat')}
            >
              <MessageCircle className="w-5 h-5 mr-2" />
              Chat with CPA Assistant
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="text-lg px-8 py-6 border-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground/10"
              onClick={() => navigate('/booking')}
            >
              Book a Consultation
            </Button>
          </div>
        </Card>

        {/* Categories Overview */}
        <div className="mt-8 grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {faqData.map((category, index) => (
            <Card key={index} className="p-4 text-center hover:shadow-medium transition-shadow cursor-pointer">
              <div className="w-10 h-10 bg-gradient-accent rounded-lg flex items-center justify-center mx-auto mb-3">
                <HelpCircle className="w-5 h-5 text-accent-foreground" />
              </div>
              <h3 className="font-medium text-card-foreground mb-1">{category.category}</h3>
              <p className="text-xs text-muted-foreground">
                {category.questions.length} questions
              </p>
            </Card>
          ))}
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default FAQ;