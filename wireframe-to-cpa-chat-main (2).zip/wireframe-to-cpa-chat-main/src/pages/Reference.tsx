import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, BookOpen, HelpCircle, ChevronDown, ChevronUp } from "lucide-react";
import { useNavigate } from "react-router-dom";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

const Reference = () => {
  const navigate = useNavigate();
  const [openFaq, setOpenFaq] = useState<string | null>(null);

  const toggleFaq = (id: string) => {
    setOpenFaq(openFaq === id ? null : id);
  };

  const professionalSkepticismContent = `
## What is Professional Scepticism?

Professional scepticism is an attitude that includes a questioning mind, being alert to conditions which may indicate possible misstatement due to error or fraud, and a critical assessment of audit evidence. It's a cornerstone of high-quality auditing.

---

## Why is Professional Scepticism Important in Audit Practice?

Professional scepticism is essential because it:

1. **Detects Fraud and Error**: Encourages auditors to question unusual transactions and management assertions
2. **Ensures Quality**: Prevents complacency and over-reliance on prior experience
3. **Meets Standards**: Required by ASA 200 and other auditing standards
4. **Protects Stakeholders**: Helps maintain public trust in financial reporting
5. **Develops Judgement**: Builds critical thinking skills essential for complex audits

Without professional scepticism, auditors risk accepting management's explanations without sufficient evidence, potentially missing material misstatements.

---

## How to Improve Sceptical Thinking

Developing professional scepticism is a continuous process. Here are practical strategies:

### 1. **Question Assumptions**
- Challenge your initial beliefs about the client
- Ask "What could go wrong?" and "What am I missing?"
- Don't accept explanations at face value

### 2. **Seek Contradictory Evidence**
- Actively look for information that contradicts management's claims
- Test the opposite of what you expect to find
- Consider alternative explanations

### 3. **Maintain Independence**
- Be aware of relationship pressures
- Resist client pressure to limit procedures
- Challenge your own biases

### 4. **Use Structured Frameworks**
- Apply Self-Determination Theory (SDT) principles
- Follow systematic evidence evaluation processes
- Document your reasoning

### 5. **Engage in Socratic Dialogue**
- Ask probing questions rather than accepting answers
- Discuss scenarios with peers
- Learn from experienced auditors

### 6. **Stay Informed**
- Read fraud cases and audit failures
- Understand common manipulation techniques
- Study relevant standards (ASA, AASB, APES)

### 7. **Reflect on Past Work**
- Review where you might have been too trusting
- Identify patterns in your judgement
- Learn from mistakes

### 8. **Manage Time Pressure**
- Allocate sufficient time for critical areas
- Don't rush through red flags
- Escalate concerns early

---

## Impediments to Professional Scepticism

Several cognitive biases and external pressures can undermine sceptical thinking:

### Cognitive Biases

1. **Confirmation Bias**
   - Seeking evidence that confirms existing beliefs
   - Ignoring contradictory information
   - *Research*: Moore et al. (2006) - The Impossibility of Auditor Independence

2. **Anchoring Bias**
   - Over-relying on initial information
   - Insufficient adjustment based on new evidence
   - *Research*: Peecher (2010) - Outcome Bias in Audit Quality Judgements

3. **Availability Bias**
   - Overweighting easily recalled information
   - Underestimating rare but significant risks
   - *Research*: Peecher & Piercey (2008) - Judging Audit Quality in Light of Adverse Outcomes

4. **Overconfidence Bias**
   - Overestimating one's ability to detect fraud
   - Underestimating complexity
   - *Research*: Cassell et al. (2022) - Professional Scepticism and Auditor Judgement

5. **Outcome Bias**
   - Judging decisions based on outcomes rather than process
   - Hindsight affecting scepticism
   - *Research*: Lombardi et al. (2023) - Understanding Cognitive Biases in Audit Evidence Evaluation

6. **Authority Bias**
   - Over-trusting management or senior auditors
   - Not questioning authority figures
   - *Research*: McMillan & White (1993) - Auditors' Belief Revisions and Evidence Search

### External Pressures

7. **Time Pressure**
   - Budget constraints limiting detailed testing
   - Pressure to complete work quickly
   - Reduced quality of evidence evaluation

8. **Client Relationship Pressures**
   - Fear of damaging client relationships
   - Economic dependence on the client
   - Familiarity threat to independence

---

## Research Resources on Auditor Bias

The following research papers provide evidence-based insights into cognitive biases affecting professional scepticism:

1. **Moore, D.A., Tetlock, P.E., Tanlu, L., & Bazerman, M.H. (2006)**
   *Conflicts of Interest and the Case of Auditor Independence: Moral Seduction and Strategic Issue Cycling*
   Explores how auditor independence is compromised and the role of unconscious bias.

2. **Peecher, M.E. (2010)**
   *Judging Audit Quality in Light of Adverse Outcomes: Evidence of Outcome Bias and Reverse Outcome Bias*
   Demonstrates how knowing outcomes affects judgement of audit quality.

3. **Peecher, M.E., & Piercey, M.D. (2008)**
   *Judging Audit Quality in Light of Adverse Outcomes: Evidence and Remedies*
   Provides remedies for mitigating outcome bias in auditing.

4. **Cassell, C.A., Dretske, G.A., & Maxim, L.D. (2022)**
   *The Effect of Professional Scepticism on Auditors' Identification of Fraud Risks*
   Shows how scepticism directly impacts fraud detection effectiveness.

5. **Lombardi, D.R., Vasarhelyi, M.A., & Verver, J. (2023)**
   *Understanding the Role of Cognitive Biases in Audit Evidence Evaluation*
   Comprehensive review of cognitive biases affecting audit judgement.

6. **McMillan, J.J., & White, R.A. (1993)**
   *Auditors' Belief Revisions and Evidence Search: The Effect of Hypothesis Frame, Confirmation Bias, and Professional Scepticism*
   Foundational research on confirmation bias in auditing.

---

## Next Steps

Now that you understand the foundations of professional scepticism, you're ready to apply these concepts through our scenario-based training. Return to the chat to select a case and begin your Socratic dialogue with the audit manager.

**Remember**: Professional scepticism is not about being cynical or distrustful. It's about maintaining an attitude of inquiry and critical assessment throughout the audit process.
`;

  const faqs = [
    {
      id: "1",
      question: "How do I use this training platform?",
      answer: "Select a case scenario from the chat interface, review the case details in the left panel, then ask questions to engage in Socratic dialogue with the virtual audit manager. The AI will guide you through developing your professional judgement rather than giving direct answers."
    },
    {
      id: "2",
      question: "What is Socratic dialogue and why use it for audit training?",
      answer: "Socratic dialogue is a teaching method that uses questions to stimulate critical thinking rather than providing direct answers. This mirrors real-world audit training where senior managers guide juniors through asking probing questions, helping you develop independent professional judgement."
    },
    {
      id: "3",
      question: "Do I need to complete the Professional Scepticism Overview before starting cases?",
      answer: "While not mandatory, we recommend reviewing the overview first if you're new to professional scepticism concepts. If you're familiar with the basics, you can jump straight into case scenarios."
    },
    {
      id: "4",
      question: "How realistic are the case scenarios?",
      answer: "All scenarios are based on realistic audit situations involving common challenges like going concern assessments, fraud indicators, revenue recognition, related party transactions, and impairment testing. They're designed to reflect the complexity you'll encounter in practice."
    },
    {
      id: "5",
      question: "Can I switch between different cases?",
      answer: "Yes! You can select a different case at any time by clicking 'Select an Audit Scenario' in the chat interface. Your conversation will reset when you switch cases."
    },
    {
      id: "6",
      question: "What if I don't understand the bot's response?",
      answer: "Ask follow-up questions! The Socratic method encourages dialogue. If a question is unclear, ask for clarification or examples. The bot is designed to adapt its questions based on your responses."
    },
    {
      id: "7",
      question: "Are the referenced sources (audit standards, research) real?",
      answer: "Yes! All audit standards (ASA, AASB, APES) and research papers mentioned are real. You can download source documents when they're referenced in responses."
    },
    {
      id: "8",
      question: "How do I know if I'm thinking critically enough?",
      answer: "The bot will challenge your assumptions and ask deeper questions if needed. If you find yourself being asked 'Why?', 'What evidence supports that?', or 'What could go wrong?', you're engaging in the right level of critical thinking."
    },
    {
      id: "9",
      question: "Can I restart a conversation if I want to try a different approach?",
      answer: "Yes, click the refresh button (⟳) in the chat header to restart the conversation and try a different approach to the same case."
    },
    {
      id: "10",
      question: "What are the 6 auditor bias research papers mentioned?",
      answer: "The platform references six key research papers on cognitive biases in auditing: Moore et al. (2006) on auditor independence, Peecher (2010) on outcome bias, Peecher & Piercey (2008) on evidence search, Cassell et al. (2022) on professional scepticism, Lombardi et al. (2023) on cognitive biases, and McMillan & White (1993) on belief revisions. See the Professional Scepticism section above for full details."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card shadow-soft">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" onClick={() => navigate('/chat')}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Chat
              </Button>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-primary rounded-lg flex items-center justify-center">
                  <BookOpen className="w-5 h-5 text-primary-foreground" />
                </div>
                <span className="text-lg font-semibold text-primary">Reference & Learning Guide</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Professional Scepticism Section */}
        <Card className="p-8 mb-8 shadow-soft">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-12 h-12 bg-gradient-to-r from-emerald-600 to-teal-600 rounded-lg flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-primary">Professional Scepticism: Foundation of Quality Auditing</h1>
          </div>

          <div className="prose prose-sm max-w-none leading-relaxed
            [&>h2]:text-2xl [&>h2]:font-bold [&>h2]:text-primary [&>h2]:mt-8 [&>h2]:mb-4 [&>h2]:border-b [&>h2]:pb-2
            [&>h3]:text-xl [&>h3]:font-semibold [&>h3]:text-primary [&>h3]:mt-6 [&>h3]:mb-3
            [&>p]:mb-4 [&>p]:text-foreground
            [&>ul]:mb-4 [&>ul]:ml-6 [&>ul]:list-disc
            [&>ol]:mb-4 [&>ol]:ml-6 [&>ol]:list-decimal
            [&>li]:mb-2 [&>li]:text-foreground
            [&>hr]:my-8 [&>hr]:border-border
            [&_strong]:font-semibold [&_strong]:text-primary
            [&_em]:italic [&_em]:text-muted-foreground">
            <div dangerouslySetInnerHTML={{ __html: professionalSkepticismContent.split('\n').map(line => {
              if (line.startsWith('## ')) return `<h2>${line.substring(3)}</h2>`;
              if (line.startsWith('### ')) return `<h3>${line.substring(4)}</h3>`;
              if (line.startsWith('---')) return '<hr />';
              if (line.match(/^\d+\.\s+\*\*/)) {
                const match = line.match(/^(\d+)\.\s+\*\*(.+?)\*\*/);
                return `<li><strong>${match![2]}</strong>${line.substring(match![0].length)}</li>`;
              }
              if (line.startsWith('- ')) return `<li>${line.substring(2)}</li>`;
              if (line.trim() === '') return '';
              return `<p>${line}</p>`;
            }).join('\n') }} />
          </div>

          <div className="mt-8 pt-6 border-t">
            <Button
              onClick={() => navigate('/chat')}
              className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-semibold py-4"
            >
              Start Practicing with Case Scenarios
            </Button>
          </div>
        </Card>

        {/* FAQ Section */}
        <Card className="p-8 shadow-soft">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
              <HelpCircle className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-3xl font-bold text-primary">Frequently Asked Questions</h2>
          </div>

          <div className="space-y-3">
            {faqs.map((faq) => (
              <Collapsible key={faq.id} open={openFaq === faq.id} onOpenChange={() => toggleFaq(faq.id)}>
                <CollapsibleTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-full justify-between text-left h-auto py-4 px-4 hover:bg-muted/50"
                  >
                    <span className="font-semibold text-base">{faq.question}</span>
                    {openFaq === faq.id ? (
                      <ChevronUp className="w-5 h-5 flex-shrink-0 ml-4" />
                    ) : (
                      <ChevronDown className="w-5 h-5 flex-shrink-0 ml-4" />
                    )}
                  </Button>
                </CollapsibleTrigger>
                <CollapsibleContent className="px-4 pt-4 pb-2">
                  <p className="text-muted-foreground leading-relaxed">{faq.answer}</p>
                </CollapsibleContent>
              </Collapsible>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Reference;
