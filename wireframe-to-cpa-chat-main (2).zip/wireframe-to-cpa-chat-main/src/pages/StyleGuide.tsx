import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Moon, Sun, Palette, Type, Component, Layout } from "lucide-react";

const StyleGuide = () => {
  const [darkMode, setDarkMode] = useState(false);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle("dark");
  };

  const colorTokens = [
    { name: "Primary", var: "--primary", desc: "Deep Navy Blue for trust and professionalism" },
    { name: "Secondary", var: "--secondary", desc: "Light Professional Grey for subtle backgrounds" },
    { name: "Accent", var: "--accent", desc: "Emerald for trust and financial growth" },
    { name: "Highlight", var: "--highlight", desc: "Subtle Teal for interactive elements" },
    { name: "Success", var: "--success", desc: "Success states and positive actions" },
    { name: "Destructive", var: "--destructive", desc: "Error states and warnings" },
    { name: "Muted", var: "--muted", desc: "Subtle backgrounds and disabled states" },
  ];

  const shadows = [
    { name: "Soft", class: "shadow-soft", desc: "Subtle elevation for cards" },
    { name: "Medium", class: "shadow-medium", desc: "Standard component elevation" },
    { name: "Strong", class: "shadow-strong", desc: "High elevation for modals" },
  ];

  const gradients = [
    { name: "Primary", class: "bg-gradient-primary", desc: "Main brand gradient" },
    { name: "Accent", class: "bg-gradient-accent", desc: "Accent gradient for highlights" },
    { name: "Subtle", class: "bg-gradient-subtle", desc: "Subtle background gradient" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-foreground mb-2">Design System Style Guide</h1>
            <p className="text-muted-foreground">Professional CPA & University Theme</p>
          </div>
          <div className="flex items-center gap-4">
            <Switch 
              checked={darkMode} 
              onCheckedChange={toggleDarkMode}
              className="data-[state=checked]:bg-primary"
            />
            <Label className="flex items-center gap-2">
              {darkMode ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
              {darkMode ? "Dark" : "Light"} Mode
            </Label>
          </div>
        </div>

        <Tabs defaultValue="colors" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="colors" className="flex items-center gap-2">
              <Palette className="h-4 w-4" />
              Colors
            </TabsTrigger>
            <TabsTrigger value="typography" className="flex items-center gap-2">
              <Type className="h-4 w-4" />
              Typography
            </TabsTrigger>
            <TabsTrigger value="components" className="flex items-center gap-2">
              <Component className="h-4 w-4" />
              Components
            </TabsTrigger>
            <TabsTrigger value="layout" className="flex items-center gap-2">
              <Layout className="h-4 w-4" />
              Layout
            </TabsTrigger>
          </TabsList>

          {/* Colors Tab */}
          <TabsContent value="colors" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Color Palette</CardTitle>
                <CardDescription>
                  Professional color scheme designed for trust and credibility in financial services
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {colorTokens.map((token) => (
                    <div key={token.name} className="space-y-2">
                      <div 
                        className="h-20 rounded-lg border"
                        style={{ backgroundColor: `hsl(var(${token.var}))` }}
                      />
                      <div>
                        <h4 className="font-semibold text-foreground">{token.name}</h4>
                        <p className="text-sm text-muted-foreground">{token.desc}</p>
                        <code className="text-xs bg-muted px-2 py-1 rounded">{token.var}</code>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Gradients */}
            <Card>
              <CardHeader>
                <CardTitle>Gradients</CardTitle>
                <CardDescription>Professional gradient combinations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {gradients.map((gradient) => (
                    <div key={gradient.name} className="space-y-2">
                      <div className={`h-20 rounded-lg ${gradient.class}`} />
                      <div>
                        <h4 className="font-semibold text-foreground">{gradient.name}</h4>
                        <p className="text-sm text-muted-foreground">{gradient.desc}</p>
                        <code className="text-xs bg-muted px-2 py-1 rounded">{gradient.class}</code>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Shadows */}
            <Card>
              <CardHeader>
                <CardTitle>Shadows</CardTitle>
                <CardDescription>Elevation system for depth and hierarchy</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {shadows.map((shadow) => (
                    <div key={shadow.name} className="space-y-2">
                      <div className={`h-20 bg-card rounded-lg ${shadow.class}`} />
                      <div>
                        <h4 className="font-semibold text-foreground">{shadow.name}</h4>
                        <p className="text-sm text-muted-foreground">{shadow.desc}</p>
                        <code className="text-xs bg-muted px-2 py-1 rounded">{shadow.class}</code>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Typography Tab */}
          <TabsContent value="typography" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Typography Scale</CardTitle>
                <CardDescription>Consistent text sizing and hierarchy</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h1 className="text-4xl font-bold text-foreground">Heading 1 - Hero Text</h1>
                  <h2 className="text-3xl font-semibold text-foreground">Heading 2 - Section Title</h2>
                  <h3 className="text-2xl font-semibold text-foreground">Heading 3 - Subsection</h3>
                  <h4 className="text-xl font-medium text-foreground">Heading 4 - Card Title</h4>
                  <h5 className="text-lg font-medium text-foreground">Heading 5 - Small Title</h5>
                  <h6 className="text-base font-medium text-foreground">Heading 6 - Label</h6>
                  <p className="text-base text-foreground">Body text - Regular paragraph content with proper line height for readability.</p>
                  <p className="text-sm text-muted-foreground">Small text - Secondary information and descriptions.</p>
                  <p className="text-xs text-muted-foreground">Extra small text - Captions and fine print.</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Components Tab */}
          <TabsContent value="components" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Button Variants</CardTitle>
                <CardDescription>All button styles and states</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-4">
                  <Button variant="default">Primary Button</Button>
                  <Button variant="secondary">Secondary Button</Button>
                  <Button variant="outline">Outline Button</Button>
                  <Button variant="ghost">Ghost Button</Button>
                  <Button variant="link">Link Button</Button>
                  <Button variant="destructive">Destructive Button</Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Form Components</CardTitle>
                <CardDescription>Input fields and form controls</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="sample-input">Text Input</Label>
                    <Input id="sample-input" placeholder="Enter text here..." />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="sample-textarea">Textarea</Label>
                    <Textarea id="sample-textarea" placeholder="Enter longer text..." />
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Switch id="sample-switch" />
                    <Label htmlFor="sample-switch">Toggle Switch</Label>
                  </div>
                  <div className="space-y-2">
                    <Label>Slider</Label>
                    <Slider defaultValue={[50]} max={100} step={1} />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Badges & Tags</CardTitle>
                <CardDescription>Status indicators and labels</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="default">Default</Badge>
                  <Badge variant="secondary">Secondary</Badge>
                  <Badge variant="outline">Outline</Badge>
                  <Badge variant="destructive">Error</Badge>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Layout Tab */}
          <TabsContent value="layout" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Spacing System</CardTitle>
                <CardDescription>Consistent spacing using Tailwind's scale</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Padding & Margin Scale:</p>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                      <div className="bg-muted p-1 rounded">p-1 (4px)</div>
                      <div className="bg-muted p-2 rounded">p-2 (8px)</div>
                      <div className="bg-muted p-4 rounded">p-4 (16px)</div>
                      <div className="bg-muted p-6 rounded">p-6 (24px)</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Border Radius</CardTitle>
                <CardDescription>Consistent corner rounding</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="h-16 bg-primary rounded-sm flex items-center justify-center text-primary-foreground text-xs">rounded-sm</div>
                  <div className="h-16 bg-primary rounded-md flex items-center justify-center text-primary-foreground text-xs">rounded-md</div>
                  <div className="h-16 bg-primary rounded-lg flex items-center justify-center text-primary-foreground text-xs">rounded-lg</div>
                  <div className="h-16 bg-primary rounded-full flex items-center justify-center text-primary-foreground text-xs">rounded-full</div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Usage Guidelines</CardTitle>
                <CardDescription>Best practices for implementing the design system</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Color Usage</h4>
                    <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                      <li>Always use semantic color tokens (e.g., <code>text-primary</code>) instead of direct colors</li>
                      <li>Primary colors for main actions and brand elements</li>
                      <li>Accent colors for highlights and secondary actions</li>
                      <li>Muted colors for supporting text and disabled states</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Typography</h4>
                    <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                      <li>Use consistent heading hierarchy (h1-h6)</li>
                      <li>Body text should be readable with proper line height</li>
                      <li>Use muted colors for secondary information</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Components</h4>
                    <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                      <li>Use button variants appropriately (primary for main actions)</li>
                      <li>Apply consistent spacing using the spacing scale</li>
                      <li>Use shadows for elevation and visual hierarchy</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default StyleGuide;