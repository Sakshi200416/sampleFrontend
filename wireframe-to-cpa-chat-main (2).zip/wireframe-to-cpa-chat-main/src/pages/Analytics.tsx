import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, BarChart3, TrendingUp, Users, MessageCircle, Clock, BookOpen, LogOut, Download, HelpCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { config } from "@/config";

const Analytics = () => {
  const navigate = useNavigate();
  const { toast } = useToast();

  // State for analytics data
  const [loading, setLoading] = useState(true);
  const [overviewStats, setOverviewStats] = useState<any>(null);
  const [dailyActivity, setDailyActivity] = useState<any[]>([]);
  const [scenarioStats, setScenarioStats] = useState<any[]>([]);
  const [recentSessions, setRecentSessions] = useState<any[]>([]);
  const [popularQuestions, setPopularQuestions] = useState<any[]>([]);

  // Check authentication on mount
  useEffect(() => {
    const token = localStorage.getItem('admin_token');
    if (!token) {
      toast({
        title: "Authentication Required",
        description: "Please log in to access analytics",
        variant: "destructive",
      });
      navigate('/login');
      return;
    }
    fetchAnalytics();
  }, []);

  const getAuthHeaders = () => {
    const token = localStorage.getItem('admin_token');
    return {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };
  };

  const fetchAnalytics = async () => {
    setLoading(true);

    try {
      const headers = getAuthHeaders();

      // Fetch overview stats
      const overviewRes = await fetch(`${config.endpoints.analytics.overview}?days=30`, { headers });
      if (overviewRes.status === 401) {
        handleUnauthorized();
        return;
      }
      const overview = await overviewRes.json();
      setOverviewStats(overview);

      // Fetch daily activity
      const dailyRes = await fetch(`${config.endpoints.analytics.daily}?days=7`, { headers });
      const daily = await dailyRes.json();
      setDailyActivity(daily.daily_activity || []);

      // Fetch scenario stats
      const scenariosRes = await fetch(config.endpoints.analytics.scenarios, { headers });
      const scenarios = await scenariosRes.json();
      setScenarioStats(scenarios.scenarios || []);

      // Fetch recent sessions
      const sessionsRes = await fetch(`${config.endpoints.analytics.sessions}?limit=10`, { headers });
      const sessions = await sessionsRes.json();
      setRecentSessions(sessions.sessions || []);

      // Fetch popular questions
      const questionsRes = await fetch(`${config.endpoints.analytics.popularQuestions}?limit=10&days=30`, { headers });
      const questions = await questionsRes.json();
      setPopularQuestions(questions.questions || []);

    } catch (error) {
      console.error('Error fetching analytics:', error);
      toast({
        title: "Error",
        description: "Failed to load analytics data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleExportCSV = async () => {
    try {
      const headers = getAuthHeaders();
      const response = await fetch(`${config.endpoints.analytics.export}?days=30`, { headers });

      if (response.status === 401) {
        handleUnauthorized();
        return;
      }

      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `analytics_export_${new Date().toISOString().split('T')[0]}.csv`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);

        toast({
          title: "Export Successful",
          description: "Analytics data has been exported to CSV",
        });
      } else {
        throw new Error('Export failed');
      }
    } catch (error) {
      console.error('Error exporting CSV:', error);
      toast({
        title: "Export Failed",
        description: "Failed to export analytics data",
        variant: "destructive",
      });
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-AU', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const formatDuration = (seconds: number) => {
    if (!seconds) return 'N/A';
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}m ${secs}s`;
  };

  const handleUnauthorized = () => {
    localStorage.removeItem('admin_token');
    localStorage.removeItem('admin_username');
    toast({
      title: "Session Expired",
      description: "Please log in again",
      variant: "destructive",
    });
    navigate('/login');
  };

  const handleLogout = () => {
    localStorage.removeItem('admin_token');
    localStorage.removeItem('admin_username');
    toast({
      title: "Logged Out",
      description: "You have been logged out successfully",
    });
    navigate('/login');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          <p className="text-muted-foreground">Loading analytics...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card shadow-soft">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" onClick={() => navigate('/chat')}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Chat
              </Button>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-primary rounded-lg flex items-center justify-center">
                  <BarChart3 className="w-5 h-5 text-primary-foreground" />
                </div>
                <span className="text-lg font-semibold text-primary">Analytics Dashboard</span>
              </div>
              <Badge variant="outline" className="ml-2">
                {localStorage.getItem('admin_username') || 'Admin'}
              </Badge>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" onClick={handleExportCSV}>
                <Download className="w-4 h-4 mr-2" />
                Export CSV
              </Button>
              <Button variant="outline" size="sm" onClick={fetchAnalytics}>
                Refresh
              </Button>
              <Button variant="ghost" size="sm" onClick={handleLogout} title="Logout">
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        {/* Overview Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-medium text-muted-foreground">Total Sessions</p>
              <Users className="w-5 h-5 text-blue-500" />
            </div>
            <p className="text-3xl font-bold">{overviewStats?.total_sessions || 0}</p>
            <p className="text-xs text-muted-foreground mt-1">Last 30 days</p>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-medium text-muted-foreground">Total Messages</p>
              <MessageCircle className="w-5 h-5 text-green-500" />
            </div>
            <p className="text-3xl font-bold">{overviewStats?.total_messages || 0}</p>
            <p className="text-xs text-muted-foreground mt-1">Conversations exchanged</p>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-medium text-muted-foreground">Avg Session Duration</p>
              <Clock className="w-5 h-5 text-purple-500" />
            </div>
            <p className="text-3xl font-bold">
              {overviewStats?.avg_session_duration_minutes
                ? `${overviewStats.avg_session_duration_minutes.toFixed(1)}m`
                : 'N/A'}
            </p>
            <p className="text-xs text-muted-foreground mt-1">Per session</p>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-medium text-muted-foreground">Avg Messages/Session</p>
              <TrendingUp className="w-5 h-5 text-orange-500" />
            </div>
            <p className="text-3xl font-bold">
              {overviewStats?.avg_messages_per_session
                ? overviewStats.avg_messages_per_session.toFixed(1)
                : 'N/A'}
            </p>
            <p className="text-xs text-muted-foreground mt-1">Engagement metric</p>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Daily Activity */}
          <Card className="p-6">
            <div className="flex items-center space-x-2 mb-4">
              <TrendingUp className="w-5 h-5 text-primary" />
              <h2 className="text-lg font-semibold">Daily Activity (Last 7 Days)</h2>
            </div>
            {dailyActivity.length > 0 ? (
              <div className="space-y-3">
                {dailyActivity.map((day, index) => (
                  <div key={index} className="flex items-center justify-between pb-3 border-b last:border-0">
                    <div>
                      <p className="font-medium">{formatDate(day.date)}</p>
                      <p className="text-sm text-muted-foreground">{day.total_messages} messages</p>
                    </div>
                    <Badge variant="outline">{day.sessions} sessions</Badge>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-center py-8">No activity data yet</p>
            )}
          </Card>

          {/* Top Scenarios */}
          <Card className="p-6">
            <div className="flex items-center space-x-2 mb-4">
              <BookOpen className="w-5 h-5 text-primary" />
              <h2 className="text-lg font-semibold">Most Popular Scenarios</h2>
            </div>
            {scenarioStats.length > 0 ? (
              <div className="space-y-3">
                {scenarioStats.slice(0, 5).map((scenario, index) => (
                  <div key={index} className="flex items-center justify-between pb-3 border-b last:border-0">
                    <div className="flex-1">
                      <p className="font-medium text-sm">{scenario.scenario_title}</p>
                      <p className="text-xs text-muted-foreground">
                        {scenario.total_sessions || 0} sessions
                      </p>
                    </div>
                    <Badge variant="default">{scenario.total_loads || 0} loads</Badge>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-center py-8">No scenario data yet</p>
            )}
          </Card>
        </div>

        {/* Popular Questions */}
        <Card className="p-6 mt-6">
          <div className="flex items-center space-x-2 mb-4">
            <HelpCircle className="w-5 h-5 text-primary" />
            <h2 className="text-lg font-semibold">Most Popular Questions (Last 30 Days)</h2>
          </div>
          {popularQuestions.length > 0 ? (
            <div className="space-y-3">
              {popularQuestions.map((question, index) => (
                <div key={index} className="flex items-start justify-between pb-3 border-b last:border-0">
                  <div className="flex-1 pr-4">
                    <p className="text-sm font-medium">{question.question}</p>
                  </div>
                  <div className="flex items-center space-x-2 flex-shrink-0">
                    <Badge variant="outline">{question.count}x</Badge>
                    <span className="text-xs text-muted-foreground">{question.percentage}%</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground text-center py-8">No question data yet</p>
          )}
        </Card>

        {/* Recent Sessions */}
        <Card className="p-6 mt-6">
          <div className="flex items-center space-x-2 mb-4">
            <Users className="w-5 h-5 text-primary" />
            <h2 className="text-lg font-semibold">Recent Sessions</h2>
          </div>
          {recentSessions.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b text-left">
                    <th className="pb-3 text-sm font-medium text-muted-foreground">Session ID</th>
                    <th className="pb-3 text-sm font-medium text-muted-foreground">Started</th>
                    <th className="pb-3 text-sm font-medium text-muted-foreground">Scenario</th>
                    <th className="pb-3 text-sm font-medium text-muted-foreground">Messages</th>
                    <th className="pb-3 text-sm font-medium text-muted-foreground">Duration</th>
                    <th className="pb-3 text-sm font-medium text-muted-foreground">Reflection</th>
                  </tr>
                </thead>
                <tbody>
                  {recentSessions.map((session, index) => (
                    <tr key={index} className="border-b last:border-0">
                      <td className="py-3 text-sm font-mono text-xs">
                        {session.session_id.slice(0, 8)}...
                      </td>
                      <td className="py-3 text-sm">{formatDate(session.started_at)}</td>
                      <td className="py-3 text-sm">
                        {session.scenario_used ? (
                          <Badge variant="outline" className="text-xs">
                            {session.scenario_used}
                          </Badge>
                        ) : (
                          <span className="text-muted-foreground">None</span>
                        )}
                      </td>
                      <td className="py-3 text-sm">{session.message_count || 0}</td>
                      <td className="py-3 text-sm">{formatDuration(session.duration_seconds)}</td>
                      <td className="py-3 text-sm">
                        {session.reflection_requested ? (
                          <Badge variant="default" className="text-xs">Yes</Badge>
                        ) : (
                          <span className="text-muted-foreground">No</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-muted-foreground text-center py-8">No sessions recorded yet</p>
          )}
        </Card>

        {/* Reflection Usage */}
        {overviewStats && (
          <Card className="p-6 mt-6">
            <div className="flex items-center space-x-2 mb-4">
              <BarChart3 className="w-5 h-5 text-primary" />
              <h2 className="text-lg font-semibold">Feature Usage</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-muted/30 rounded-lg">
                <p className="text-2xl font-bold text-primary">{overviewStats.reflection_usage || 0}</p>
                <p className="text-sm text-muted-foreground mt-1">Reflection Requests</p>
              </div>
              <div className="text-center p-4 bg-muted/30 rounded-lg">
                <p className="text-2xl font-bold text-primary">{scenarioStats.length}</p>
                <p className="text-sm text-muted-foreground mt-1">Scenarios Used</p>
              </div>
              <div className="text-center p-4 bg-muted/30 rounded-lg">
                <p className="text-2xl font-bold text-primary">
                  {overviewStats.total_sessions > 0
                    ? ((overviewStats.reflection_usage / overviewStats.total_sessions) * 100).toFixed(0)
                    : 0}%
                </p>
                <p className="text-sm text-muted-foreground mt-1">Reflection Usage Rate</p>
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default Analytics;
