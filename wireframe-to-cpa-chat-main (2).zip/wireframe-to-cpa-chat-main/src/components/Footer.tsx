import cpaLogo from "@/assets/cpa-logo.webp";
import jcuLogo from "@/assets/jcu-logo-clear.jpg";

const Footer = () => {
  return (
    <footer className="border-t bg-card/50 py-8 px-4">
      <div className="container mx-auto">
        <div className="flex flex-col items-center space-y-6">
          {/* Partner Logos */}
          <div className="flex flex-col items-center space-y-4">
            <p className="text-sm font-medium text-foreground">Proudly supported by</p>
            <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-8">
              <div className="flex items-center space-x-2">
                <img 
                  src={cpaLogo} 
                  alt="CPA Australia - Australian Society of CPAs" 
                  className="h-24 w-auto object-contain"
                />
              </div>
              <div className="flex items-center space-x-2">
                <img 
                  src={jcuLogo} 
                  alt="James Cook University Australia" 
                  className="h-24 w-auto object-contain"
                />
              </div>
            </div>
          </div>
          
          {/* Copyright */}
          <div className="text-center text-sm text-muted-foreground border-t pt-4 w-full">
            <p>&copy; 2024 CPA Chatbot. Professional accounting assistance you can trust.</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;