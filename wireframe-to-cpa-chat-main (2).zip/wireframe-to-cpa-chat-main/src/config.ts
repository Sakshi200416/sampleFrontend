/**
 * Frontend Configuration
 * Dynamically determines API URL based on environment
 */

// Check if we're in development or production
const isDevelopment = import.meta.env.DEV;

// Get API URL from environment variable or use default based on current location
const getApiUrl = (): string => {
  // 1. First priority: explicit environment variable
  if (import.meta.env.VITE_API_URL) {
    return import.meta.env.VITE_API_URL;
  }

  // 2. Second priority: infer from current window location (for remote access)
  if (typeof window !== 'undefined') {
    const protocol = window.location.protocol;
    const hostname = window.location.hostname;

    // If accessing via localhost, use localhost:5001
    if (hostname === 'localhost' || hostname === '127.0.0.1') {
      return `${protocol}//localhost:5001`;
    }

    // Special case: promptandpixel.com.au Cloudflare tunnel
    // Frontend: cpa-chatbot.promptandpixel.com.au
    // Backend: cpabe.promptandpixel.com.au
    if (hostname === 'cpa-chatbot.promptandpixel.com.au') {
      return `${protocol}//cpabe.promptandpixel.com.au`;
    }

    // If accessing via remote domain/tunnel, use same host with port 5001
    // This handles other cloudflare tunnels, ngrok, etc.
    return `${protocol}//${hostname}:5001`;
  }

  // 3. Production fallback: Use production backend URL
  if (!isDevelopment) {
    return 'https://cpabe.promptandpixel.com.au';
  }

  // 4. Development fallback: default to localhost
  return 'http://localhost:5001';
};

// Create config object with getters for runtime evaluation
export const config = {
  get apiUrl() {
    return getApiUrl();
  },
  isDevelopment,
  endpoints: {
    get chat() {
      return `${getApiUrl()}/api/chat`;
    },
    get reset() {
      return `${getApiUrl()}/api/reset`;
    },
    get health() {
      return `${getApiUrl()}/health`;
    },
    auth: {
      get login() {
        return `${getApiUrl()}/api/auth/login`;
      },
      get verify() {
        return `${getApiUrl()}/api/auth/verify`;
      },
    },
    analytics: {
      get overview() {
        return `${getApiUrl()}/api/analytics/overview`;
      },
      get daily() {
        return `${getApiUrl()}/api/analytics/daily`;
      },
      get scenarios() {
        return `${getApiUrl()}/api/analytics/scenarios`;
      },
      get sessions() {
        return `${getApiUrl()}/api/analytics/sessions`;
      },
      get popularQuestions() {
        return `${getApiUrl()}/api/analytics/popular-questions`;
      },
      get export() {
        return `${getApiUrl()}/api/analytics/export`;
      },
    },
    get download() {
      return `${getApiUrl()}/api/download`;
    },
    get downloadSource() {
      return `${getApiUrl()}/api/download-source`;
    },
    get introduction() {
      return `${getApiUrl()}/api/introduction`;
    },
    get reflection() {
      return `${getApiUrl()}/api/reflection`;
    },
  },
};

// Log configuration in development
if (isDevelopment) {
  console.log('🔧 Frontend Config:', {
    apiUrl: config.apiUrl,
    location: typeof window !== 'undefined' ? window.location.href : 'SSR',
  });
}
